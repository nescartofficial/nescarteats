<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<footer class="footer text-center text-dark">
    All Rights Reserved by <?= SITE_NAME; ?>. Designed and Developed by <a href="https://oniontabs.com" target="_blank">Oniontabs</a>.
</footer>

<!-- ============================================================== -->
<!-- End footer -->
<!-- ============================================================== -->

</div>

<!-- ============================================================== -->
<!-- End Page Wrapper -->
<!-- ============================================================== -->
<div class="modal fade" id="infomodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="col info"></div>
            </div>
        </div>
    </div>
</div>
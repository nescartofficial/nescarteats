 <!-- scripts -->
 <script src="assets/stroyka/vendor/jquery/jquery.min.js"></script>
 <script src="assets/stroyka/vendor/feather-icons/feather.min.js"></script>
 <script src="assets/stroyka/vendor/simplebar/simplebar.min.js"></script>
 <script src="assets/stroyka/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="assets/stroyka/vendor/highlight.js/highlight.pack.js"></script>
 <script src="assets/stroyka/vendor/quill/quill.min.js"></script>
 <script src="assets/stroyka/vendor/air-datepicker/js/datepicker.min.js"></script>
 <script src="assets/stroyka/vendor/air-datepicker/js/i18n/datepicker.en.js"></script>
 <script src="assets/stroyka/vendor/select2/js/select2.min.js"></script>
 <script src="assets/stroyka/vendor/fontawesome/js/all.min.js" data-auto-replace-svg="" async=""></script>
 <script src="assets/stroyka/vendor/chart.js/chart.min.js"></script>
 <script src="assets/stroyka/vendor/datatables/js/jquery.dataTables.min.js"></script>
 <script src="assets/stroyka/vendor/datatables/js/dataTables.bootstrap5.min.js"></script>
 <script src="assets/stroyka/vendor/nouislider/nouislider.min.js"></script>
 <script src="assets/stroyka/vendor/fullcalendar/main.min.js"></script>
 <script src="assets/stroyka/js/stroyka.js"></script>
 <script src="assets/stroyka/js/custom.js"></script>
 <script src="assets/stroyka/js/calendar.js"></script>
 <script src="assets/stroyka/js/demo.js"></script>
 <script src="assets/stroyka/js/demo-chart-js.js"></script>
 
 <script src="assets/vendors/slugit/jquery.slugit.min.js"></script>
 <script src="assets/js/site.js?vs=2.1"></script>
 </body>
 <!-- Mirrored from stroyka-admin.html.themeforest.scompiler.ru/variants/ltr/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 08 Dec 2021 11:55:14 GMT -->

 </html>
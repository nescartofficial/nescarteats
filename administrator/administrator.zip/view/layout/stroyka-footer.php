<!-- sa-app__footer -->
<div class="sa-app__footer d-block d-md-flex">
    <!-- copyright --><?= SITE_NAME; ?> © 2021<div class="m-auto"></div>
    <div>Developed by <a href="https://oniontabs.com" target="_blank">Oniontabs</a></div>
    <!-- copyright / end -->
</div><!-- sa-app__footer / end -->
</div><!-- sa-app__content / end -->
<!-- sa-app__toasts -->
<div class="sa-app__toasts toast-container bottom-0 end-0"></div><!-- sa-app__toasts / end -->
</div><!-- sa-app / end -->